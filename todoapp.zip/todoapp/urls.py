from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index1'),
    path('add', views.addtodo, name='add'),
    path('complete/<todo_id>', views.completetodo, name='complete'),
    path('deletecomplete', views.deletecomplete, name='delcomplete'),
    path('delall', views.delall, name='delall'),
    path('contact', views.contact, name='contact')
]
