from datetime import datetime

from django.shortcuts import render, redirect
from .models import Todo
from .forms import Todoform, Newtodoform
from django.views.decorators.http import require_POST
from django.http import HttpResponse


def index(request):
    content = Todo.objects.order_by('id')
    # form = Todoform()
    form = Newtodoform()
    mydate = datetime.now()
    context = {'content': content, 'form': form,'mydate': mydate}
    return render(request, 'todo/index.html', context)


@ require_POST
def addtodo(request):
     # form =Todoform(request.POST)
     # todo = Todo.objects.order_by('id')
     newtoform = Newtodoform(request.POST)

     if newtoform.is_valid():
             # newtodo= Todo(text=form.cleaned_data['text'])
             # newtodo.save()
         newto = newtoform.save()
     print(request.POST['text'])
     return redirect('index1')


def completetodo(request, todo_id):
    todo=Todo.objects.get(pk=todo_id)
    todo.complete=True
    todo.save()
    return redirect('index1')

def deletecomplete(request):
        Todo.objects.filter(complete__exact=True).delete()
        return redirect('index1')
def delall(request):
        Todo.objects.all().delete()
        return redirect('index1')
def contact(request):
    return render(request,'todo/contact.html')